
'use client';
import { MLAnalysis } from '@/components/ml-analysis';

export default function MlAnalysisPage() {
    return <MLAnalysis />;
}
