import { CloudServices } from '@/components/cloud-services';

export default function CloudServicesPage() {
    return <CloudServices />;
}
