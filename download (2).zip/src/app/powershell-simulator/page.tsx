import { ThreatSandbox } from '@/components/powershell-simulator';

export default function SandboxPage() {
    return <ThreatSandbox />;
}
