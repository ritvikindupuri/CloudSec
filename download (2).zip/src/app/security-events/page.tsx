import { SecurityEvents } from '@/components/security-events';

export default function SecurityEventsPage() {
    return <SecurityEvents />;
}
